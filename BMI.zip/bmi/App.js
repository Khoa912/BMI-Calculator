import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, Button } from 'react-native';

export default function App() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBMI] = useState('0.00');

  const calculateBMI = () => {
    const weightValue = parseFloat(weight);
    const heightValue = parseFloat(height);

    if (isNaN(weightValue) || isNaN(heightValue) || heightValue <= 0) {
      setBMI('0.00');
      return;
    }

    const bmiValue = weightValue / Math.pow(heightValue / 100, 2);
    setBMI(bmiValue.toFixed(2));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Weight (KG):</Text>
      <TextInput
        style={styles.input}
        placeholder=" Nhập Cân nặng."
        keyboardType="numeric"
        value={weight}
        onChangeText={(text) => setWeight(text)}
      />

      <Text style={styles.label}>Height (CM):</Text>
      <TextInput
        style={styles.input}
        placeholder=" Nhập Chiều Cao."
        keyboardType="numeric"
        value={height}
        onChangeText={(text) => setHeight(text)}
      />

      <View style={styles.resultContainer}>
        <Text style={styles.resultLabel} >BMI: <Text style={styles.result}>{bmi}</Text></Text>
        
      </View>

      <View style={styles.buttonContainer}>
        <Button title="Compute" onPress={calculateBMI} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'lightblue',
    borderWidth:2,
   
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 130,
    marginTop: 20,
    marginBottom:10,
    fontFamily: 'Arial',
  },
  input: {
    height: 40,
    width: '80%',
    borderColor: 'grey',
    backgroundColor: "lightgray",
    borderWidth: 1,
    marginBottom: 16,
    paddingLeft: 8,
  },
  resultContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  resultLabel: {
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'Arial',
  },
  result: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'red',
    marginTop: 8,
  },
  buttonContainer: {
    marginTop: 19,
  
   
    
  },
});